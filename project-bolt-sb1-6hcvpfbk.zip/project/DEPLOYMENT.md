# دليل نشر التطبيق
## Deploy the Application as a Web App

---

## 🚀 نشر سريع على Vercel (موصى به)

### الخطوات:

#### 1. إنشاء حساب على Vercel

1. اذهب إلى: https://vercel.com/signup
2. سجل باستخدام GitHub (موصى به) أو Email
3. أكمل التسجيل

#### 2. رفع المشروع إلى GitHub

إذا لم يكن المشروع على GitHub بعد:

```bash
# في مجلد المشروع
git init
git add .
git commit -m "Initial commit - Alwaleed Philanthropies Messaging System"

# أنشئ repository جديد على GitHub
# ثم اربطه:
git remote add origin https://github.com/your-username/alwaleed-messaging.git
git branch -M main
git push -u origin main
```

#### 3. نشر على Vercel

**الطريقة الأولى: من Dashboard**

1. اذهب إلى: https://vercel.com/new
2. اختر repository من GitHub
3. اختر المشروع
4. **مهم**: أضف Environment Variables:
   ```
   VITE_SUPABASE_URL = your_supabase_url
   VITE_SUPABASE_ANON_KEY = your_anon_key
   ```
5. اضغط **Deploy**
6. انتظر 2-3 دقائق
7. **ستحصل على رابط مثل**: `https://alwaleed-messaging.vercel.app`

**الطريقة الثانية: من Terminal**

```bash
# تثبيت Vercel CLI
npm i -g vercel

# تسجيل الدخول
vercel login

# نشر التطبيق
vercel

# اتبع التعليمات:
# - Set up and deploy? Y
# - Which scope? (اختر حسابك)
# - Link to existing project? N
# - What's your project's name? alwaleed-messaging
# - In which directory is your code? ./
# - Want to modify settings? N

# بعد النشر، أضف Environment Variables:
vercel env add VITE_SUPABASE_URL
# (أدخل القيمة)

vercel env add VITE_SUPABASE_ANON_KEY
# (أدخل القيمة)

# أعد النشر:
vercel --prod
```

**الرابط النهائي**: `https://your-project-name.vercel.app`

---

## 🌐 نشر على Netlify

### الخطوات:

#### 1. إنشاء حساب

1. اذهب إلى: https://app.netlify.com/signup
2. سجل باستخدام GitHub أو Email

#### 2. نشر من Dashboard

1. اضغط **Add new site** > **Import an existing project**
2. اختر **GitHub**
3. اختر repository
4. **Build settings**:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. **Environment variables**:
   ```
   VITE_SUPABASE_URL = your_supabase_url
   VITE_SUPABASE_ANON_KEY = your_anon_key
   ```
6. اضغط **Deploy site**

**الرابط**: `https://your-site-name.netlify.app`

#### 3. نشر من Terminal

```bash
# تثبيت Netlify CLI
npm install -g netlify-cli

# تسجيل الدخول
netlify login

# بناء التطبيق
npm run build

# نشر
netlify deploy

# اتبع التعليمات ثم:
netlify deploy --prod

# أو اختصار:
netlify init
# ثم اتبع التعليمات
```

---

## ☁️ نشر على Cloudflare Pages

### الخطوات:

1. اذهب إلى: https://dash.cloudflare.com/
2. اختر **Pages** من القائمة
3. **Create a project** > **Connect to Git**
4. اختر repository
5. **Build settings**:
   - Framework preset: `Vite`
   - Build command: `npm run build`
   - Build output: `dist`
6. **Environment variables**:
   ```
   VITE_SUPABASE_URL = your_supabase_url
   VITE_SUPABASE_ANON_KEY = your_anon_key
   ```
7. **Save and Deploy**

**الرابط**: `https://your-project.pages.dev`

---

## 📱 نشر على Firebase Hosting

### الخطوات:

```bash
# تثبيت Firebase CLI
npm install -g firebase-tools

# تسجيل الدخول
firebase login

# تهيئة المشروع
firebase init hosting

# اختر:
# - Hosting setup
# - Use existing project or create new
# - Public directory: dist
# - Single-page app: Yes
# - Set up automatic builds: No

# بناء التطبيق
npm run build

# نشر
firebase deploy
```

**الرابط**: `https://your-project.web.app`

---

## ⚙️ إعداد Environment Variables

### مهم جداً!

يجب إضافة متغيرات البيئة في منصة النشر:

```
VITE_SUPABASE_URL = https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY = eyJhbGciOi...
```

### كيفية الحصول عليها:

1. اذهب إلى: https://supabase.com/dashboard
2. اختر مشروعك
3. اذهب إلى **Settings** > **API**
4. انسخ:
   - Project URL → `VITE_SUPABASE_URL`
   - anon/public key → `VITE_SUPABASE_ANON_KEY`

---

## 🔧 إعداد Domain مخصص (اختياري)

### على Vercel:

1. اذهب إلى Project Settings > Domains
2. اضغط **Add**
3. أدخل domain الخاص بك
4. اتبع التعليمات لإعداد DNS

### على Netlify:

1. اذهب إلى Site settings > Domain management
2. اضغط **Add custom domain**
3. أدخل domain
4. أعد DNS records

---

## ✅ التحقق من النشر

بعد النشر، تأكد من:

1. **الرابط يعمل**
   - افتح الرابط في المتصفح
   - يجب أن تظهر صفحة تسجيل الدخول

2. **Environment Variables مضبوطة**
   - افتح Console (F12)
   - اكتب: `console.log(import.meta.env.VITE_SUPABASE_URL)`
   - يجب أن يظهر الرابط

3. **الاتصال بـ Supabase يعمل**
   - جرب تسجيل الدخول
   - إذا نجح، كل شيء يعمل!

4. **Storage Bucket معد**
   - راجع `STORAGE_SETUP.md`
   - تأكد من إنشاء bucket `attachments`

---

## 🐛 استكشاف الأخطاء

### خطأ "Build failed"

**الحل:**
```bash
# جرب البناء محلياً:
npm run build

# إذا نجح، المشكلة في الإعداد
# إذا فشل، أصلح الأخطاء
```

### خطأ "Environment variables not found"

**الحل:**
- تأكد من إضافة المتغيرات في منصة النشر
- يجب أن تبدأ بـ `VITE_`
- أعد النشر بعد الإضافة

### الصفحة بيضاء

**الحل:**
1. افتح Console (F12)
2. شاهد الأخطاء
3. غالباً: Environment variables مفقودة

### خطأ "Failed to fetch"

**الحل:**
- تأكد من `VITE_SUPABASE_URL` صحيح
- تأكد من `VITE_SUPABASE_ANON_KEY` صحيح
- تحقق من Supabase project نشط

---

## 📊 مقارنة المنصات

| المنصة | السعر | السرعة | السهولة | موصى به |
|--------|-------|---------|----------|----------|
| Vercel | مجاني* | ⚡⚡⚡ | ✅✅✅ | ⭐⭐⭐ |
| Netlify | مجاني* | ⚡⚡⚡ | ✅✅✅ | ⭐⭐⭐ |
| Cloudflare | مجاني | ⚡⚡⚡ | ✅✅ | ⭐⭐ |
| Firebase | مجاني* | ⚡⚡ | ✅✅ | ⭐⭐ |

*مجاني مع حدود، خطط مدفوعة للاستخدام الكثيف

---

## 🎯 التوصية

**للأفضلية**: استخدم **Vercel**
- سهل جداً
- سريع
- تكامل ممتاز مع React/Vite
- Free tier سخي
- SSL تلقائي
- رابط مباشر فوري

---

## 📞 الحصول على المساعدة

إذا واجهت مشاكل:

1. راجع هذا الدليل
2. افتح Console (F12) وشاهد الأخطاء
3. راجع `TROUBLESHOOTING.md`
4. تواصل مع دعم المنصة

---

## 🎉 بعد النشر

شارك الرابط مع:
- فريق المؤسسة
- المستفيدين
- الإدارة

**مثال الرابط النهائي**:
```
https://alwaleed-messaging.vercel.app
أو
https://alwaleed-messaging.netlify.app
```

---

**آخر تحديث**: 16 يناير 2026
**الإصدار**: 1.0
**الحالة**: ✅ جاهز للنشر
