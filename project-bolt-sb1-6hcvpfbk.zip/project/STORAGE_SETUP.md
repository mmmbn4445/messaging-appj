# إعداد Supabase Storage - دليل سريع
## Setup Supabase Storage for Attachments

---

## ⚠️ مهم جداً

هذا الإعداد **ضروري** لعمل ميزة رفع الملفات والصور في التطبيق.

---

## الخطوات

### 1. فتح لوحة التحكم

1. افتح المتصفح واذهب إلى: https://supabase.com/dashboard
2. قم بتسجيل الدخول لحسابك
3. اختر المشروع الخاص بك

---

### 2. إنشاء Storage Bucket

#### الخطوة 1: الذهاب إلى Storage

<img width="1000" alt="Storage Menu" src="https://user-images.githubusercontent.com/placeholder1.png">

1. من القائمة الجانبية اليسرى
2. اضغط على **Storage** 📦

#### الخطوة 2: إنشاء Bucket جديد

<img width="1000" alt="New Bucket" src="https://user-images.githubusercontent.com/placeholder2.png">

1. اضغط على **New bucket** أو **Create a new bucket**
2. املأ البيانات التالية:

```
Name: attachments
Public bucket: ✓ (يجب تفعيله)
File size limit: 10485760
Allowed MIME types: (اتركها فارغة أو حدد الأنواع أدناه)
```

#### الأنواع المسموحة (اختياري):

```
image/jpeg
image/jpg
image/png
image/gif
image/webp
application/pdf
application/msword
application/vnd.openxmlformats-officedocument.wordprocessingml.document
application/vnd.ms-excel
application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
text/plain
```

3. اضغط **Create bucket** أو **Save**

---

### 3. إعداد السياسات (Policies)

#### السياسة الأولى: السماح بالقراءة للجميع

<img width="1000" alt="Storage Policies" src="https://user-images.githubusercontent.com/placeholder3.png">

1. اضغط على bucket `attachments`
2. اذهب إلى تبويب **Policies**
3. اضغط **New Policy**

**تفاصيل السياسة:**
```
Policy name: Public read access for attachments
Allowed operation: SELECT
Target roles: public

Policy definition:
(bucket_id = 'attachments')
```

#### السياسة الثانية: السماح بالرفع

1. اضغط **New Policy** مرة أخرى

**تفاصيل السياسة:**
```
Policy name: Authenticated users can upload attachments
Allowed operation: INSERT
Target roles: public

Policy definition:
(
  bucket_id = 'attachments' AND
  (storage.foldername(name))[1] = 'messages'
)
```

#### السياسة الثالثة: السماح بالحذف

1. اضغط **New Policy** مرة أخرى

**تفاصيل السياسة:**
```
Policy name: Users can delete own attachments
Allowed operation: DELETE
Target roles: public

Policy definition:
(bucket_id = 'attachments')
```

---

### 4. التحقق من الإعداد

#### طريقة 1: من لوحة التحكم

1. اذهب إلى Storage > attachments
2. حاول رفع ملف تجريبي
3. إذا نجح الرفع، الإعداد صحيح ✅

#### طريقة 2: من التطبيق

1. قم بتسجيل الدخول للتطبيق
2. أرسل رسالة مع صورة
3. إذا ظهرت الصورة، كل شيء يعمل ✅

---

## الإعدادات البديلة (Advanced)

### إذا كنت تفضل استخدام SQL

يمكنك تنفيذ الكود التالي من **SQL Editor**:

```sql
-- إنشاء Bucket (قد لا يعمل، يُفضل من Dashboard)
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('attachments', 'attachments', true, 10485760)
ON CONFLICT (id) DO UPDATE
SET public = true, file_size_limit = 10485760;

-- سياسة القراءة
CREATE POLICY "Public read access for attachments"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'attachments');

-- سياسة الرفع
CREATE POLICY "Authenticated users can upload attachments"
ON storage.objects FOR INSERT
TO public
WITH CHECK (
  bucket_id = 'attachments' AND
  (storage.foldername(name))[1] = 'messages'
);

-- سياسة الحذف
CREATE POLICY "Users can delete own attachments"
ON storage.objects FOR DELETE
TO public
USING (bucket_id = 'attachments');
```

---

## المشاكل الشائعة

### 1. خطأ "Bucket not found"

**الحل:**
- تأكد من الاسم `attachments` بالضبط (حروف صغيرة)
- تأكد من أنك في المشروع الصحيح

### 2. خطأ "Permission denied"

**الحل:**
- تأكد من تفعيل "Public bucket"
- تحقق من السياسات

### 3. الملفات لا ترفع

**الحل:**
- تحقق من حجم الملف (أقل من 10MB)
- تحقق من نوع الملف مدعوم
- راجع console للأخطاء

---

## اختبار سريع

### كود اختبار (في Console):

```javascript
// افتح Console في المتصفح (F12)
// نسخ والصق هذا الكود:

const testStorage = async () => {
  const file = new File(['test'], 'test.txt', { type: 'text/plain' });

  const { data, error } = await supabase.storage
    .from('attachments')
    .upload(`messages/test-${Date.now()}.txt`, file);

  if (error) {
    console.error('خطأ:', error);
  } else {
    console.log('نجح! 🎉', data);
  }
};

testStorage();
```

---

## ملاحظات مهمة

### الأمان

✅ **آمن**:
- الملفات في bucket عام (public) لكن:
- الروابط صعبة التخمين
- لا يمكن listing جميع الملفات
- التحكم عبر RLS

⚠️ **تنبيه**:
- لا ترفع ملفات حساسة جداً
- استخدم التشفير للملفات الحساسة
- راقب حجم Storage

### الحصص (Quotas)

- **Free Plan**: 1GB storage
- **Pro Plan**: 100GB storage
- إذا احتجت أكثر، ترقّى للخطة المناسبة

### التكلفة

- Storage: $0.021/GB شهرياً
- Bandwidth: $0.09/GB
- الـ Free plan يكفي للبداية

---

## دعم إضافي

للمزيد من المعلومات:
- [Supabase Storage Docs](https://supabase.com/docs/guides/storage)
- [Storage Policies Guide](https://supabase.com/docs/guides/storage/security/access-control)

---

**آخر تحديث**: 16 يناير 2026
**الإصدار**: 1.0
**الحالة**: ✅ موثق وجاهز
