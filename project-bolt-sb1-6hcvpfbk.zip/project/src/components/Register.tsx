import { useState } from 'react';
import { UserPlus, User, Lock, FileText } from 'lucide-react';
import { register as authRegister } from '../lib/auth';
import { useAuth } from '../contexts/AuthContext';

interface RegisterProps {
  onSwitchToLogin: () => void;
}

export default function Register({ onSwitchToLogin }: RegisterProps) {
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!fullName || !username || !password || !confirmPassword) {
      setError('يرجى إدخال جميع البيانات');
      setLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      setError('كلمة المرور غير متطابقة');
      setLoading(false);
      return;
    }

    if (password.length < 6) {
      setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      setLoading(false);
      return;
    }

    const { user, error: registerError } = await authRegister(fullName, username, password);

    if (registerError || !user) {
      setError(registerError || 'حدث خطأ أثناء التسجيل');
      setLoading(false);
      return;
    }

    login(user);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-emerald-100">
          <div className="text-center mb-8">
            <img
              src="/alwaleed-1_(1).jpg"
              alt="Alwaleed Philanthropies"
              className="h-20 mx-auto mb-6 object-contain"
            />
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              نظام مراسلات مؤسسة الوليد للإنسانية
            </h1>
            <p className="text-gray-600">إنشاء حساب جديد</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm text-center">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                الاسم الكامل
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-4 py-3 pr-11 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition text-right"
                  placeholder="أدخل الاسم الكامل"
                  dir="rtl"
                />
                <FileText className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                اسم المستخدم
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-3 pr-11 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition text-right"
                  placeholder="اختر اسم مستخدم فريد"
                  dir="rtl"
                />
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 pr-11 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition text-right"
                  placeholder="أدخل كلمة المرور (6 أحرف على الأقل)"
                  dir="rtl"
                />
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                تأكيد كلمة المرور
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-3 pr-11 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition text-right"
                  placeholder="أعد إدخال كلمة المرور"
                  dir="rtl"
                />
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-3 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'جاري إنشاء الحساب...' : 'إنشاء حساب'}
            </button>

            <div className="text-center">
              <p className="text-gray-600">
                لديك حساب بالفعل؟{' '}
                <button
                  type="button"
                  onClick={onSwitchToLogin}
                  className="text-emerald-600 hover:text-emerald-700 font-medium"
                >
                  تسجيل الدخول
                </button>
              </p>
            </div>
          </form>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 mt-6">
          <p className="text-sm text-emerald-800 text-center leading-relaxed">
            مرحباً بك في نظام مراسلات مؤسسة الوليد للإنسانية.<br />
            يمكنك من خلال هذا النظام التواصل معنا مباشرة، وسيتم الرد عليك من فريق المؤسسة في أقرب وقت ممكن.
          </p>
        </div>
      </div>
    </div>
  );
}
