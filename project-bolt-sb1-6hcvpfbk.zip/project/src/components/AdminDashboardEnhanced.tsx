import { useState, useEffect, useRef } from 'react';
import { LogOut, Users, MessageSquare, Search, Send, Settings, Image as ImageIcon, Paperclip, X, Download, FileText } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface Conversation {
  id: string;
  user_id: string;
  status: string;
  created_at: string;
  updated_at: string;
  user: {
    full_name: string;
    username: string;
  };
  messages: Message[];
}

interface Message {
  id: string;
  content: string;
  is_from_admin: boolean;
  created_at: string;
  sender_id: string;
  is_read?: boolean;
  attachments?: Attachment[];
}

interface Attachment {
  id: string;
  file_name: string;
  file_type: string;
  file_size: number;
  file_url: string;
}

interface AutoReplySettings {
  id: string;
  message: string;
  is_enabled: boolean;
}

export default function AdminDashboardEnhanced() {
  const { user, logout } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [autoReplySettings, setAutoReplySettings] = useState<AutoReplySettings | null>(null);
  const [autoReplyMessage, setAutoReplyMessage] = useState('');
  const [autoReplyEnabled, setAutoReplyEnabled] = useState(true);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadConversations();
    loadAutoReplySettings();
  }, []);

  useEffect(() => {
    if (selectedConversation) {
      const channel = supabase
        .channel(`conversation-${selectedConversation.id}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `conversation_id=eq.${selectedConversation.id}`
          },
          () => {
            loadConversations();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [selectedConversation]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedConversation?.messages]);

  const loadAutoReplySettings = async () => {
    const { data } = await supabase
      .from('auto_reply_settings')
      .select('*')
      .maybeSingle();

    if (data) {
      setAutoReplySettings(data);
      setAutoReplyMessage(data.message);
      setAutoReplyEnabled(data.is_enabled);
    }
  };

  const saveAutoReplySettings = async () => {
    if (!autoReplyMessage.trim()) {
      alert('الرجاء إدخال رسالة الرد التلقائي');
      return;
    }

    setLoading(true);

    if (autoReplySettings) {
      await supabase
        .from('auto_reply_settings')
        .update({
          message: autoReplyMessage,
          is_enabled: autoReplyEnabled
        })
        .eq('id', autoReplySettings.id);
    } else {
      await supabase
        .from('auto_reply_settings')
        .insert([{
          message: autoReplyMessage,
          is_enabled: autoReplyEnabled
        }]);
    }

    await loadAutoReplySettings();
    setLoading(false);
    setShowSettings(false);
    alert('تم حفظ الإعدادات بنجاح');
  };

  const loadMessageAttachments = async (message: Message): Promise<Message> => {
    const { data: attachments } = await supabase
      .from('message_attachments')
      .select('*')
      .eq('message_id', message.id);

    return {
      ...message,
      attachments: attachments || []
    };
  };

  const loadConversations = async () => {
    const { data: convs } = await supabase
      .from('conversations')
      .select(`
        *,
        user:users!conversations_user_id_fkey(full_name, username)
      `)
      .order('updated_at', { ascending: false });

    if (convs) {
      const convsWithMessages = await Promise.all(
        convs.map(async (conv) => {
          const { data: msgs } = await supabase
            .from('messages')
            .select('*')
            .eq('conversation_id', conv.id)
            .order('created_at', { ascending: true });

          const msgsWithAttachments = await Promise.all(
            (msgs || []).map(msg => loadMessageAttachments(msg))
          );

          return {
            ...conv,
            user: Array.isArray(conv.user) ? conv.user[0] : conv.user,
            messages: msgsWithAttachments
          };
        })
      );

      setConversations(convsWithMessages);

      if (selectedConversation) {
        const updated = convsWithMessages.find(c => c.id === selectedConversation.id);
        if (updated) {
          setSelectedConversation(updated);
        }
      }
    }
  };

  const uploadFile = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `messages/${fileName}`;

      console.log('Uploading file:', file.name, 'to:', filePath);

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('attachments')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        alert(`خطأ في رفع الملف: ${uploadError.message}`);
        return null;
      }

      console.log('Upload successful:', uploadData);

      const { data } = supabase.storage
        .from('attachments')
        .getPublicUrl(filePath);

      console.log('Public URL:', data.publicUrl);

      return data.publicUrl;
    } catch (error) {
      console.error('Exception in uploadFile:', error);
      alert('حدث خطأ أثناء رفع الملف. تأكد من إعداد Storage Bucket.');
      return null;
    }
  };

  const sendMessage = async () => {
    if ((!newMessage.trim() && selectedFiles.length === 0) || !selectedConversation || !user) return;

    setLoading(true);
    setUploading(true);

    try {
      const { data: messageData, error: messageError } = await supabase
        .from('messages')
        .insert([
          {
            conversation_id: selectedConversation.id,
            sender_id: user.id,
            content: newMessage.trim() || 'مرفق',
            is_from_admin: true
          }
        ])
        .select()
        .single();

      if (messageError || !messageData) {
        throw new Error('فشل إرسال الرسالة');
      }

      if (selectedFiles.length > 0) {
        for (const file of selectedFiles) {
          const fileUrl = await uploadFile(file);
          if (fileUrl) {
            const { error: attachError } = await supabase.from('message_attachments').insert([{
              message_id: messageData.id,
              file_name: file.name,
              file_type: file.type,
              file_size: file.size,
              file_url: fileUrl
            }]);

            if (attachError) {
              console.error('Error saving attachment:', attachError);
              alert(`خطأ في حفظ المرفق: ${attachError.message}`);
            } else {
              console.log('Attachment saved successfully:', file.name);
            }
          } else {
            alert(`فشل رفع الملف: ${file.name}`);
          }
        }
      }

      setNewMessage('');
      setSelectedFiles([]);
      await loadConversations();
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setLoading(false);
      setUploading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      const maxSize = 10 * 1024 * 1024;
      if (file.size > maxSize) {
        alert(`${file.name} أكبر من 10MB`);
        return false;
      }
      return true;
    });

    setSelectedFiles(prev => [...prev, ...validFiles].slice(0, 5));
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const updateConversationStatus = async (convId: string, status: string) => {
    await supabase
      .from('conversations')
      .update({ status })
      .eq('id', convId);

    await loadConversations();
  };

  const filteredConversations = conversations.filter(conv =>
    conv.user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conv.user.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getLastMessage = (conv: Conversation) => {
    if (conv.messages.length === 0) return 'لا توجد رسائل بعد';
    const lastMsg = conv.messages[conv.messages.length - 1];
    return lastMsg.content.substring(0, 50) + (lastMsg.content.length > 50 ? '...' : '');
  };

  const getUnreadCount = (conv: Conversation) => {
    return conv.messages.filter(m => !m.is_from_admin && !m.is_read).length;
  };

  const isImage = (type: string) => type.startsWith('image/');

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  if (showSettings) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 p-6">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
            <div className="flex items-center gap-3 mb-6">
              <img
                src="/alwaleed-1_(1).jpg"
                alt="Logo"
                className="h-12 object-contain"
              />
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900">إعدادات الرد التلقائي</h1>
                <p className="text-sm text-gray-600">يتم إرسال هذه الرسالة تلقائياً عند أول رسالة من المستخدم</p>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <label className="flex items-center gap-2 mb-4">
                  <input
                    type="checkbox"
                    checked={autoReplyEnabled}
                    onChange={(e) => setAutoReplyEnabled(e.target.checked)}
                    className="w-5 h-5 text-emerald-600 rounded focus:ring-emerald-500"
                  />
                  <span className="text-sm font-medium text-gray-700">تفعيل الرد التلقائي</span>
                </label>

                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  رسالة الرد التلقائي
                </label>
                <textarea
                  value={autoReplyMessage}
                  onChange={(e) => setAutoReplyMessage(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none resize-none text-right"
                  rows={6}
                  dir="rtl"
                  placeholder="نشكركم على تواصلكم مع مؤسسة الوليد للإنسانية..."
                />
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                <p className="text-sm text-emerald-800 leading-relaxed">
                  ملاحظة: سيتم إرسال هذه الرسالة مرة واحدة فقط لكل مستخدم عند إرساله لأول رسالة.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={saveAutoReplySettings}
                  disabled={loading}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-3 rounded-lg transition disabled:opacity-50"
                >
                  {loading ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
                </button>
                <button
                  onClick={() => setShowSettings(false)}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-3 rounded-lg transition"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex">
      <div className="w-96 bg-white border-r border-slate-200 flex flex-col">
        <div className="bg-slate-900 text-white p-6">
          <div className="flex items-center gap-3 mb-4">
            <img
              src="/alwaleed-1_(1).jpg"
              alt="Logo"
              className="h-12 object-contain brightness-0 invert"
            />
          </div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h1 className="text-lg font-bold">لوحة التحكم</h1>
              <p className="text-sm text-slate-300">{user?.full_name}</p>
            </div>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 bg-emerald-600 hover:bg-emerald-700 rounded-lg transition"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300 transition"
          >
            <LogOut className="w-4 h-4" />
            <span>تسجيل الخروج</span>
          </button>
        </div>

        <div className="p-4 border-b border-slate-200">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="البحث عن مستخدم..."
              className="w-full px-4 py-2 pr-10 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-right text-sm"
              dir="rtl"
            />
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="p-8 text-center">
              <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 text-sm">لا توجد محادثات</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredConversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => setSelectedConversation(conv)}
                  className={`w-full p-4 text-right hover:bg-slate-50 transition ${
                    selectedConversation?.id === conv.id ? 'bg-emerald-50' : ''
                  }`}
                >
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{conv.user.full_name}</h3>
                      <p className="text-xs text-slate-500">@{conv.user.username}</p>
                    </div>
                    {getUnreadCount(conv) > 0 && (
                      <span className="bg-emerald-600 text-white text-xs px-2 py-1 rounded-full">
                        {getUnreadCount(conv)}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-600 truncate">{getLastMessage(conv)}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className={`text-xs px-2 py-1 rounded ${
                      conv.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {conv.status === 'active' ? 'نشط' : 'مغلق'}
                    </span>
                    <span className="text-xs text-slate-400">
                      {new Date(conv.updated_at).toLocaleDateString('ar-SA')}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            <div className="bg-white border-b border-slate-200 p-4">
              <div className="flex items-center justify-between">
                <div className="text-right">
                  <h2 className="text-lg font-bold text-gray-900">
                    {selectedConversation.user.full_name}
                  </h2>
                  <p className="text-sm text-slate-600">@{selectedConversation.user.username}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => updateConversationStatus(selectedConversation.id, 'active')}
                    className="px-3 py-1 text-xs bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition"
                  >
                    تفعيل
                  </button>
                  <button
                    onClick={() => updateConversationStatus(selectedConversation.id, 'closed')}
                    className="px-3 py-1 text-xs bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition"
                  >
                    إغلاق
                  </button>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {selectedConversation.messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <p className="text-slate-500">لا توجد رسائل في هذه المحادثة</p>
                </div>
              ) : (
                <>
                  {selectedConversation.messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.is_from_admin ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                          message.is_from_admin
                            ? 'bg-emerald-600 text-white'
                            : 'bg-white border border-slate-200 shadow-sm'
                        }`}
                      >
                        <p className={`text-sm leading-relaxed whitespace-pre-wrap ${
                          message.is_from_admin ? 'text-white' : 'text-gray-900'
                        }`}>
                          {message.content}
                        </p>

                        {message.attachments && message.attachments.length > 0 && (
                          <div className="mt-3 space-y-2">
                            {message.attachments.map((attachment) => (
                              <div key={attachment.id}>
                                {isImage(attachment.file_type) ? (
                                  <div className="rounded-lg overflow-hidden">
                                    <img
                                      src={attachment.file_url}
                                      alt={attachment.file_name}
                                      className="max-w-full h-auto rounded-lg"
                                    />
                                  </div>
                                ) : (
                                  <a
                                    href={attachment.file_url}
                                    download={attachment.file_name}
                                    className={`flex items-center gap-2 p-2 rounded-lg ${
                                      message.is_from_admin
                                        ? 'bg-emerald-700 hover:bg-emerald-800'
                                        : 'bg-slate-50 hover:bg-slate-100'
                                    }`}
                                  >
                                    <FileText className="w-4 h-4" />
                                    <div className="flex-1 text-xs">
                                      <p className="font-medium truncate">{attachment.file_name}</p>
                                      <p className="opacity-75">{formatFileSize(attachment.file_size)}</p>
                                    </div>
                                    <Download className="w-4 h-4" />
                                  </a>
                                )}
                              </div>
                            ))}
                          </div>
                        )}

                        <p className={`text-xs mt-1 ${
                          message.is_from_admin ? 'text-emerald-100' : 'text-slate-400'
                        }`}>
                          {new Date(message.created_at).toLocaleString('ar-SA', {
                            dateStyle: 'short',
                            timeStyle: 'short'
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>

            <div className="bg-white border-t border-slate-200 p-4">
              {selectedFiles.length > 0 && (
                <div className="mb-3 flex flex-wrap gap-2">
                  {selectedFiles.map((file, index) => (
                    <div key={index} className="relative bg-emerald-50 rounded-lg p-2 pr-8 text-xs">
                      <p className="font-medium truncate max-w-[150px]">{file.name}</p>
                      <p className="text-gray-500">{formatFileSize(file.size)}</p>
                      <button
                        onClick={() => removeFile(index)}
                        className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex gap-3">
                <div className="flex gap-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading || selectedFiles.length >= 5}
                    className="flex-shrink-0 bg-gray-100 hover:bg-gray-200 text-gray-700 p-3 rounded-xl transition disabled:opacity-50"
                  >
                    <ImageIcon className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading || selectedFiles.length >= 5}
                    className="flex-shrink-0 bg-gray-100 hover:bg-gray-200 text-gray-700 p-3 rounded-xl transition disabled:opacity-50"
                  >
                    <Paperclip className="w-5 h-5" />
                  </button>
                </div>

                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="اكتب ردك هنا..."
                  className="flex-1 px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none resize-none text-right"
                  rows={2}
                  dir="rtl"
                />

                <button
                  onClick={sendMessage}
                  disabled={loading || uploading || (!newMessage.trim() && selectedFiles.length === 0)}
                  className="flex-shrink-0 bg-emerald-600 hover:bg-emerald-700 text-white p-3 rounded-xl transition disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {uploading ? '...' : <Send className="w-5 h-5" />}
                </button>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <img
                src="/alwaleed-1_(1).jpg"
                alt="Logo"
                className="h-24 mx-auto mb-6 object-contain opacity-30"
              />
              <MessageSquare className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">اختر محادثة للبدء</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
