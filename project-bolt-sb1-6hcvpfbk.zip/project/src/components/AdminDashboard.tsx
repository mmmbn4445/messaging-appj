import { useState, useEffect } from 'react';
import { LogOut, Users, MessageSquare, Search, Send } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface Conversation {
  id: string;
  user_id: string;
  status: string;
  created_at: string;
  updated_at: string;
  user: {
    full_name: string;
    username: string;
  };
  messages: Message[];
}

interface Message {
  id: string;
  content: string;
  is_from_admin: boolean;
  created_at: string;
  sender_id: string;
  is_read?: boolean;
}

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    if (selectedConversation) {
      const channel = supabase
        .channel(`conversation-${selectedConversation.id}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `conversation_id=eq.${selectedConversation.id}`
          },
          () => {
            loadConversations();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [selectedConversation]);

  const loadConversations = async () => {
    const { data: convs } = await supabase
      .from('conversations')
      .select(`
        *,
        user:users!conversations_user_id_fkey(full_name, username)
      `)
      .order('updated_at', { ascending: false });

    if (convs) {
      const convsWithMessages = await Promise.all(
        convs.map(async (conv) => {
          const { data: msgs } = await supabase
            .from('messages')
            .select('*')
            .eq('conversation_id', conv.id)
            .order('created_at', { ascending: true });

          return {
            ...conv,
            user: Array.isArray(conv.user) ? conv.user[0] : conv.user,
            messages: msgs || []
          };
        })
      );

      setConversations(convsWithMessages);

      if (selectedConversation) {
        const updated = convsWithMessages.find(c => c.id === selectedConversation.id);
        if (updated) {
          setSelectedConversation(updated);
        }
      }
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation || !user) return;

    setLoading(true);

    const { error } = await supabase
      .from('messages')
      .insert([
        {
          conversation_id: selectedConversation.id,
          sender_id: user.id,
          content: newMessage.trim(),
          is_from_admin: true
        }
      ]);

    if (!error) {
      setNewMessage('');
      await loadConversations();
    }

    setLoading(false);
  };

  const updateConversationStatus = async (convId: string, status: string) => {
    await supabase
      .from('conversations')
      .update({ status })
      .eq('id', convId);

    await loadConversations();
  };

  const filteredConversations = conversations.filter(conv =>
    conv.user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conv.user.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getLastMessage = (conv: Conversation) => {
    if (conv.messages.length === 0) return 'لا توجد رسائل بعد';
    const lastMsg = conv.messages[conv.messages.length - 1];
    return lastMsg.content.substring(0, 50) + (lastMsg.content.length > 50 ? '...' : '');
  };

  const getUnreadCount = (conv: Conversation) => {
    return conv.messages.filter(m => !m.is_from_admin && !m.is_read).length;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex">
      <div className="w-96 bg-white border-r border-slate-200 flex flex-col">
        <div className="bg-slate-900 text-white p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold">لوحة التحكم</h1>
              <p className="text-sm text-slate-300">{user?.full_name}</p>
            </div>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300 transition"
          >
            <LogOut className="w-4 h-4" />
            <span>تسجيل الخروج</span>
          </button>
        </div>

        <div className="p-4 border-b border-slate-200">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="البحث عن مستخدم..."
              className="w-full px-4 py-2 pr-10 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-right text-sm"
              dir="rtl"
            />
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="p-8 text-center">
              <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 text-sm">لا توجد محادثات</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredConversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => setSelectedConversation(conv)}
                  className={`w-full p-4 text-right hover:bg-slate-50 transition ${
                    selectedConversation?.id === conv.id ? 'bg-emerald-50' : ''
                  }`}
                >
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{conv.user.full_name}</h3>
                      <p className="text-xs text-slate-500">@{conv.user.username}</p>
                    </div>
                    {getUnreadCount(conv) > 0 && (
                      <span className="bg-emerald-600 text-white text-xs px-2 py-1 rounded-full">
                        {getUnreadCount(conv)}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-600 truncate">{getLastMessage(conv)}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className={`text-xs px-2 py-1 rounded ${
                      conv.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {conv.status === 'active' ? 'نشط' : 'مغلق'}
                    </span>
                    <span className="text-xs text-slate-400">
                      {new Date(conv.updated_at).toLocaleDateString('ar-SA')}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            <div className="bg-white border-b border-slate-200 p-4">
              <div className="flex items-center justify-between">
                <div className="text-right">
                  <h2 className="text-lg font-bold text-gray-900">
                    {selectedConversation.user.full_name}
                  </h2>
                  <p className="text-sm text-slate-600">@{selectedConversation.user.username}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => updateConversationStatus(selectedConversation.id, 'active')}
                    className="px-3 py-1 text-xs bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition"
                  >
                    تفعيل
                  </button>
                  <button
                    onClick={() => updateConversationStatus(selectedConversation.id, 'closed')}
                    className="px-3 py-1 text-xs bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition"
                  >
                    إغلاق
                  </button>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {selectedConversation.messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <p className="text-slate-500">لا توجد رسائل في هذه المحادثة</p>
                </div>
              ) : (
                selectedConversation.messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.is_from_admin ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                        message.is_from_admin
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white border border-slate-200 shadow-sm'
                      }`}
                    >
                      <p className={`text-sm leading-relaxed whitespace-pre-wrap ${
                        message.is_from_admin ? 'text-white' : 'text-gray-900'
                      }`}>
                        {message.content}
                      </p>
                      <p className={`text-xs mt-1 ${
                        message.is_from_admin ? 'text-emerald-100' : 'text-slate-400'
                      }`}>
                        {new Date(message.created_at).toLocaleString('ar-SA', {
                          dateStyle: 'short',
                          timeStyle: 'short'
                        })}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="bg-white border-t border-slate-200 p-4">
              <div className="flex gap-3">
                <button
                  onClick={sendMessage}
                  disabled={loading || !newMessage.trim()}
                  className="flex-shrink-0 bg-emerald-600 hover:bg-emerald-700 text-white p-3 rounded-xl transition disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-5 h-5" />
                </button>
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="اكتب ردك هنا..."
                  className="flex-1 px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none resize-none text-right"
                  rows={2}
                  dir="rtl"
                />
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageSquare className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">اختر محادثة للبدء</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
