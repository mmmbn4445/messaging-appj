import { useState, useEffect, useRef } from 'react';
import { Send, LogOut, Image as ImageIcon, Paperclip, X, Download, FileText } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface Message {
  id: string;
  content: string;
  is_from_admin: boolean;
  created_at: string;
  sender_id: string;
  attachments?: Attachment[];
}

interface Attachment {
  id: string;
  file_name: string;
  file_type: string;
  file_size: number;
  file_url: string;
}

export default function ChatEnhanced() {
  const { user, logout } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (user) {
      loadConversation();
    }
  }, [user]);

  useEffect(() => {
    if (conversationId) {
      const channel = supabase
        .channel(`conversation-${conversationId}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `conversation_id=eq.${conversationId}`
          },
          async (payload) => {
            const newMsg = payload.new as Message;
            const msgWithAttachments = await loadMessageAttachments(newMsg);
            setMessages((prev) => [...prev, msgWithAttachments]);
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [conversationId]);

  const loadMessageAttachments = async (message: Message): Promise<Message> => {
    const { data: attachments } = await supabase
      .from('message_attachments')
      .select('*')
      .eq('message_id', message.id);

    return {
      ...message,
      attachments: attachments || []
    };
  };

  const loadConversation = async () => {
    if (!user) return;

    const { data: conversation } = await supabase
      .from('conversations')
      .select('id')
      .eq('user_id', user.id)
      .maybeSingle();

    if (conversation) {
      setConversationId(conversation.id);
      await loadMessages(conversation.id);
    } else {
      const { data: newConversation } = await supabase
        .from('conversations')
        .insert([{ user_id: user.id }])
        .select()
        .single();

      if (newConversation) {
        setConversationId(newConversation.id);
      }
    }
  };

  const loadMessages = async (convId: string) => {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', convId)
      .order('created_at', { ascending: true });

    if (data) {
      const messagesWithAttachments = await Promise.all(
        data.map(async (msg) => {
          const { data: attachments } = await supabase
            .from('message_attachments')
            .select('*')
            .eq('message_id', msg.id);

          return {
            ...msg,
            attachments: attachments || []
          };
        })
      );
      setMessages(messagesWithAttachments);
    }
  };

  const checkAndSendAutoReply = async (convId: string, userId: string) => {
    const { data: alreadySent } = await supabase
      .from('auto_reply_sent')
      .select('id')
      .eq('user_id', userId)
      .maybeSingle();

    if (alreadySent) return;

    const { data: settings } = await supabase
      .from('auto_reply_settings')
      .select('*')
      .maybeSingle();

    if (!settings || !settings.is_enabled) return;

    await supabase.from('messages').insert([{
      conversation_id: convId,
      sender_id: userId,
      content: settings.message,
      is_from_admin: true
    }]);

    await supabase.from('auto_reply_sent').insert([{
      user_id: userId
    }]);
  };

  const uploadFile = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `messages/${fileName}`;

      console.log('Uploading file:', file.name, 'to:', filePath);

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('attachments')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        alert(`خطأ في رفع الملف: ${uploadError.message}`);
        return null;
      }

      console.log('Upload successful:', uploadData);

      const { data } = supabase.storage
        .from('attachments')
        .getPublicUrl(filePath);

      console.log('Public URL:', data.publicUrl);

      return data.publicUrl;
    } catch (error) {
      console.error('Exception in uploadFile:', error);
      alert('حدث خطأ أثناء رفع الملف. تأكد من إعداد Storage Bucket.');
      return null;
    }
  };

  const sendMessage = async () => {
    if ((!newMessage.trim() && selectedFiles.length === 0) || !conversationId || !user) return;

    setLoading(true);
    setUploading(true);

    try {
      const isFirstMessage = messages.length === 0;

      const { data: messageData, error: messageError } = await supabase
        .from('messages')
        .insert([
          {
            conversation_id: conversationId,
            sender_id: user.id,
            content: newMessage.trim() || 'مرفق',
            is_from_admin: false
          }
        ])
        .select()
        .single();

      if (messageError || !messageData) {
        throw new Error('فشل إرسال الرسالة');
      }

      if (selectedFiles.length > 0) {
        for (const file of selectedFiles) {
          const fileUrl = await uploadFile(file);
          if (fileUrl) {
            const { error: attachError } = await supabase.from('message_attachments').insert([{
              message_id: messageData.id,
              file_name: file.name,
              file_type: file.type,
              file_size: file.size,
              file_url: fileUrl
            }]);

            if (attachError) {
              console.error('Error saving attachment:', attachError);
              alert(`خطأ في حفظ المرفق: ${attachError.message}`);
            } else {
              console.log('Attachment saved successfully:', file.name);
            }
          } else {
            alert(`فشل رفع الملف: ${file.name}`);
          }
        }
      }

      if (isFirstMessage) {
        await checkAndSendAutoReply(conversationId, user.id);
      }

      setNewMessage('');
      setSelectedFiles([]);
      await loadMessages(conversationId);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setLoading(false);
      setUploading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      const maxSize = 10 * 1024 * 1024;
      if (file.size > maxSize) {
        alert(`${file.name} أكبر من 10MB`);
        return false;
      }
      return true;
    });

    setSelectedFiles(prev => [...prev, ...validFiles].slice(0, 5));
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const isImage = (type: string) => {
    return type.startsWith('image/');
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex flex-col">
      <header className="bg-white border-b border-emerald-100 shadow-sm">
        <div className="max-w-4xl mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <img
              src="/alwaleed-1_(1).jpg"
              alt="Alwaleed Philanthropies"
              className="h-8 sm:h-12 object-contain"
            />
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <div className="text-left hidden sm:block">
              <p className="text-sm font-medium text-gray-900">{user?.full_name}</p>
              <p className="text-xs text-gray-500">@{user?.username}</p>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm text-red-600 hover:bg-red-50 rounded-lg transition"
            >
              <LogOut className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">خروج</span>
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-4 py-4 overflow-y-auto">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center px-4">
              <img
                src="/alwaleed-1_(1).jpg"
                alt="Alwaleed Philanthropies"
                className="h-16 sm:h-24 mx-auto mb-4 sm:mb-6 object-contain opacity-50"
              />
              <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">
                مرحباً بك في نظام المراسلات
              </h2>
              <p className="text-sm sm:text-base text-gray-600 max-w-md">
                يمكنك الآن إرسال رسالتك أو مرفقاتك إلى مؤسسة الوليد للإنسانية، وسيتم الرد عليك من قبل فريق المؤسسة في أقرب وقت ممكن.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-3 sm:space-y-4 pb-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.is_from_admin ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[85%] sm:max-w-[70%] rounded-2xl px-3 sm:px-4 py-2.5 sm:py-3 ${
                    message.is_from_admin
                      ? 'bg-white border border-emerald-100 shadow-sm'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {message.is_from_admin && (
                    <div className="flex items-center gap-2 mb-2">
                      <img
                        src="/alwaleed-1_(1).jpg"
                        alt="Logo"
                        className="h-5 object-contain"
                      />
                      <p className="text-xs font-medium text-emerald-600">
                        مؤسسة الوليد للإنسانية
                      </p>
                    </div>
                  )}
                  <p className={`text-sm leading-relaxed whitespace-pre-wrap ${message.is_from_admin ? 'text-gray-900' : 'text-white'}`}>
                    {message.content}
                  </p>

                  {message.attachments && message.attachments.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {message.attachments.map((attachment) => (
                        <div key={attachment.id}>
                          {isImage(attachment.file_type) ? (
                            <div className="rounded-lg overflow-hidden">
                              <img
                                src={attachment.file_url}
                                alt={attachment.file_name}
                                className="max-w-full h-auto rounded-lg"
                              />
                            </div>
                          ) : (
                            <a
                              href={attachment.file_url}
                              download={attachment.file_name}
                              className={`flex items-center gap-2 p-2 rounded-lg ${
                                message.is_from_admin
                                  ? 'bg-emerald-50 hover:bg-emerald-100'
                                  : 'bg-emerald-700 hover:bg-emerald-800'
                              }`}
                            >
                              <FileText className="w-4 h-4" />
                              <div className="flex-1 text-xs">
                                <p className="font-medium truncate">{attachment.file_name}</p>
                                <p className="opacity-75">{formatFileSize(attachment.file_size)}</p>
                              </div>
                              <Download className="w-4 h-4" />
                            </a>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  <p className={`text-xs mt-2 ${message.is_from_admin ? 'text-gray-400' : 'text-emerald-100'}`}>
                    {new Date(message.created_at).toLocaleTimeString('ar-SA', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      <div className="bg-white border-t border-emerald-100 shadow-lg">
        <div className="max-w-4xl mx-auto px-3 sm:px-4 py-3 sm:py-4">
          {selectedFiles.length > 0 && (
            <div className="mb-2 sm:mb-3 flex flex-wrap gap-1.5 sm:gap-2">
              {selectedFiles.map((file, index) => (
                <div key={index} className="relative bg-emerald-50 rounded-lg p-1.5 sm:p-2 pr-7 sm:pr-8 text-xs">
                  <p className="font-medium truncate max-w-[100px] sm:max-w-[150px]">{file.name}</p>
                  <p className="text-gray-500 text-[10px] sm:text-xs">{formatFileSize(file.size)}</p>
                  <button
                    onClick={() => removeFile(index)}
                    className="absolute top-0.5 sm:top-1 right-0.5 sm:right-1 bg-red-500 text-white rounded-full p-0.5 sm:p-1"
                  >
                    <X className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2 sm:gap-3">
            <div className="flex gap-1 sm:gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading || selectedFiles.length >= 5}
                className="flex-shrink-0 bg-gray-100 hover:bg-gray-200 text-gray-700 p-2 sm:p-3 rounded-xl transition disabled:opacity-50"
              >
                <ImageIcon className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading || selectedFiles.length >= 5}
                className="flex-shrink-0 bg-gray-100 hover:bg-gray-200 text-gray-700 p-2 sm:p-3 rounded-xl transition disabled:opacity-50"
              >
                <Paperclip className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            </div>

            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="اكتب رسالتك هنا..."
              className="flex-1 px-3 sm:px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none resize-none text-right"
              rows={2}
              dir="rtl"
            />

            <button
              onClick={sendMessage}
              disabled={loading || uploading || (!newMessage.trim() && selectedFiles.length === 0)}
              className="flex-shrink-0 bg-emerald-600 hover:bg-emerald-700 text-white p-2 sm:p-3 rounded-xl transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {uploading ? '...' : <Send className="w-4 h-4 sm:w-5 sm:h-5" />}
            </button>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
            onChange={handleFileSelect}
            className="hidden"
          />

          <p className="text-[10px] sm:text-xs text-gray-500 text-center mt-1.5 sm:mt-2">
            يمكنك إرفاق حتى 5 ملفات (10MB كحد أقصى لكل ملف)
          </p>
        </div>
      </div>
    </div>
  );
}
