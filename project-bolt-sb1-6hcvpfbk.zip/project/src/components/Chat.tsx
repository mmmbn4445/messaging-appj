import { useState, useEffect, useRef } from 'react';
import { Send, LogOut, MessageCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface Message {
  id: string;
  content: string;
  is_from_admin: boolean;
  created_at: string;
  sender_id: string;
}

export default function Chat() {
  const { user, logout } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (user) {
      loadConversation();
    }
  }, [user]);

  useEffect(() => {
    if (conversationId) {
      const channel = supabase
        .channel(`conversation-${conversationId}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `conversation_id=eq.${conversationId}`
          },
          (payload) => {
            setMessages((prev) => [...prev, payload.new as Message]);
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [conversationId]);

  const loadConversation = async () => {
    if (!user) return;

    const { data: conversation } = await supabase
      .from('conversations')
      .select('id')
      .eq('user_id', user.id)
      .maybeSingle();

    if (conversation) {
      setConversationId(conversation.id);
      await loadMessages(conversation.id);
    } else {
      const { data: newConversation } = await supabase
        .from('conversations')
        .insert([{ user_id: user.id }])
        .select()
        .single();

      if (newConversation) {
        setConversationId(newConversation.id);
      }
    }
  };

  const loadMessages = async (convId: string) => {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', convId)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !conversationId || !user) return;

    setLoading(true);

    const { error } = await supabase
      .from('messages')
      .insert([
        {
          conversation_id: conversationId,
          sender_id: user.id,
          content: newMessage.trim(),
          is_from_admin: false
        }
      ]);

    if (!error) {
      setNewMessage('');
      await loadMessages(conversationId);
    }

    setLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex flex-col">
      <header className="bg-white border-b border-emerald-100 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-emerald-600" />
            </div>
            <div className="text-right">
              <h1 className="text-lg font-bold text-gray-900">مؤسسة الوليد للإنسانية</h1>
              <p className="text-sm text-emerald-600">متصل الآن</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-left">
              <p className="text-sm font-medium text-gray-900">{user?.full_name}</p>
              <p className="text-xs text-gray-500">@{user?.username}</p>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition"
            >
              <LogOut className="w-4 h-4" />
              <span>خروج</span>
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 max-w-4xl w-full mx-auto p-4 overflow-y-auto">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-10 h-10 text-emerald-600" />
              </div>
              <h2 className="text-xl font-bold text-gray-900 mb-2">
                مرحباً بك في نظام المراسلات
              </h2>
              <p className="text-gray-600 max-w-md">
                يمكنك الآن إرسال رسالتك إلى مؤسسة الوليد للإنسانية، وسيتم الرد عليك من قبل فريق المؤسسة في أقرب وقت ممكن.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4 pb-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.is_from_admin ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                    message.is_from_admin
                      ? 'bg-white border border-emerald-100 shadow-sm'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {message.is_from_admin && (
                    <p className="text-xs font-medium text-emerald-600 mb-1">
                      مؤسسة الوليد للإنسانية
                    </p>
                  )}
                  <p className={`text-sm leading-relaxed whitespace-pre-wrap ${message.is_from_admin ? 'text-gray-900' : 'text-white'}`}>
                    {message.content}
                  </p>
                  <p className={`text-xs mt-1 ${message.is_from_admin ? 'text-gray-400' : 'text-emerald-100'}`}>
                    {new Date(message.created_at).toLocaleTimeString('ar-SA', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      <div className="bg-white border-t border-emerald-100 shadow-lg">
        <div className="max-w-4xl mx-auto p-4">
          <div className="flex gap-3">
            <button
              onClick={sendMessage}
              disabled={loading || !newMessage.trim()}
              className="flex-shrink-0 bg-emerald-600 hover:bg-emerald-700 text-white p-3 rounded-xl transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="اكتب رسالتك هنا..."
              className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none resize-none text-right"
              rows={2}
              dir="rtl"
            />
          </div>
          <p className="text-xs text-gray-500 text-center mt-2">
            تم إرسال رسالتك بنجاح، وسيتم الرد عليك من قبل فريق المؤسسة
          </p>
        </div>
      </div>
    </div>
  );
}
