import { supabase } from './supabase';

export interface User {
  id: string;
  full_name: string;
  username: string;
  user_type: 'beneficiary' | 'admin';
  created_at: string;
  last_login: string;
}

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function register(fullName: string, username: string, password: string): Promise<{ user: User | null; error: string | null }> {
  try {
    const { data: existingUser } = await supabase
      .from('users')
      .select('id')
      .eq('username', username)
      .maybeSingle();

    if (existingUser) {
      return { user: null, error: 'اسم المستخدم موجود بالفعل' };
    }

    const passwordHash = await hashPassword(password);

    const { data, error } = await supabase
      .from('users')
      .insert([
        {
          full_name: fullName,
          username: username,
          password_hash: passwordHash,
          user_type: 'beneficiary'
        }
      ])
      .select()
      .single();

    if (error) throw error;

    await supabase
      .from('conversations')
      .insert([{ user_id: data.id }]);

    return { user: data, error: null };
  } catch (error) {
    return { user: null, error: 'حدث خطأ أثناء التسجيل' };
  }
}

export async function login(username: string, password: string): Promise<{ user: User | null; error: string | null }> {
  try {
    const passwordHash = await hashPassword(password);

    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .eq('password_hash', passwordHash)
      .maybeSingle();

    if (error || !data) {
      return { user: null, error: 'اسم المستخدم أو كلمة المرور غير صحيحة' };
    }

    await supabase
      .from('users')
      .update({ last_login: new Date().toISOString() })
      .eq('id', data.id);

    return { user: data, error: null };
  } catch (error) {
    return { user: null, error: 'حدث خطأ أثناء تسجيل الدخول' };
  }
}

export async function logout(): Promise<void> {
  localStorage.removeItem('current_user');
}

export function getCurrentUser(): User | null {
  const userStr = localStorage.getItem('current_user');
  if (!userStr) return null;
  try {
    return JSON.parse(userStr);
  } catch {
    return null;
  }
}

export function saveCurrentUser(user: User): void {
  localStorage.setItem('current_user', JSON.stringify(user));
}
