import { useState } from 'react';
import { useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import Register from './components/Register';
import ChatEnhanced from './components/ChatEnhanced';
import AdminDashboardEnhanced from './components/AdminDashboardEnhanced';

function App() {
  const { user, loading, isAdmin } = useAuth();
  const [showRegister, setShowRegister] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <img
            src="/alwaleed-1_(1).jpg"
            alt="Alwaleed Philanthropies"
            className="h-20 mx-auto mb-6 object-contain opacity-50"
          />
          <div className="w-16 h-16 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return showRegister ? (
      <Register onSwitchToLogin={() => setShowRegister(false)} />
    ) : (
      <Login onSwitchToRegister={() => setShowRegister(true)} />
    );
  }

  return isAdmin ? <AdminDashboardEnhanced /> : <ChatEnhanced />;
}

export default App;
