# 🚀 انشر التطبيق الآن - خطوات سريعة
## Deploy Your App in 5 Minutes

---

## ✨ أسرع طريقة: Vercel (موصى به بشدة)

### الخطوة 1: افتح Vercel

اذهب إلى: **https://vercel.com/new**

### الخطوة 2: سجل دخول

- اختر **Continue with GitHub**
- أو **Continue with Email**

### الخطوة 3: ارفع المشروع

#### الطريقة أ: من GitHub (الأفضل)

1. **ارفع المشروع إلى GitHub أولاً**:
   ```bash
   # في مجلد المشروع، افتح Terminal:
   git init
   git add .
   git commit -m "Alwaleed Philanthropies Messaging System"
   ```

2. **أنشئ repository على GitHub**:
   - اذهب إلى: https://github.com/new
   - اسم Repository: `alwaleed-messaging`
   - اضغط **Create repository**

3. **اربط وارفع**:
   ```bash
   git remote add origin https://github.com/YOUR-USERNAME/alwaleed-messaging.git
   git branch -M main
   git push -u origin main
   ```

4. **في Vercel**:
   - اختر repository من القائمة
   - اضغط **Import**

#### الطريقة ب: رفع مباشر (سريع)

في Terminal:
```bash
# ثبت Vercel CLI
npm i -g vercel

# سجل دخول
vercel login

# انشر!
vercel
```

### الخطوة 4: أضف Environment Variables

**مهم جداً!**

في صفحة الإعدادات:

1. اضغط **Environment Variables**
2. أضف:
   ```
   Name: VITE_SUPABASE_URL
   Value: YOUR_SUPABASE_PROJECT_URL
   ```
3. أضف:
   ```
   Name: VITE_SUPABASE_ANON_KEY
   Value: YOUR_SUPABASE_ANON_KEY
   ```

**للحصول عليهما**:
- افتح: https://supabase.com/dashboard
- اختر مشروعك
- Settings > API
- انسخ: Project URL و anon/public key

### الخطوة 5: انشر!

اضغط **Deploy**

**🎉 بعد 2-3 دقائق، ستحصل على رابط مثل**:
```
https://alwaleed-messaging.vercel.app
```

---

## 🌐 البديل: Netlify

### خطوات سريعة:

1. **اذهب إلى**: https://app.netlify.com/drop

2. **اسحب مجلد `dist`** إلى الصفحة
   ```bash
   # أولاً، ابنِ المشروع:
   npm run build

   # ثم اسحب مجلد dist إلى Netlify
   ```

3. **انتظر قليلاً**

4. **أضف Environment Variables**:
   - Site settings > Build & deploy > Environment
   - أضف المتغيرات نفسها

**🎉 ستحصل على رابط مثل**:
```
https://alwaleed-messaging.netlify.app
```

---

## ⚡ أسرع طريقة على الإطلاق (Netlify Drop)

```bash
# 1. ابنِ التطبيق
npm run build

# 2. افتح
https://app.netlify.com/drop

# 3. اسحب مجلد dist
# 4. ستحصل على رابط فوراً!
```

**⚠️ ملاحظة**: يجب إضافة Environment Variables لاحقاً من Site Settings

---

## 📋 Checklist قبل النشر

- ✅ البناء يعمل: `npm run build`
- ✅ لديك حساب Supabase
- ✅ لديك SUPABASE_URL و ANON_KEY
- ✅ Storage Bucket `attachments` معد
- ✅ قاعدة البيانات جاهزة

---

## 🔗 الروابط النهائية

بعد النشر، سيكون لديك رابط مثل:

**Vercel**:
```
https://your-project-name.vercel.app
```

**Netlify**:
```
https://your-project-name.netlify.app
```

**أو مع Domain مخصص**:
```
https://messaging.alwaleed.org
```

---

## ✅ بعد النشر

1. **اختبر الرابط**
2. **جرب تسجيل حساب جديد**
3. **جرب إرسال رسالة**
4. **جرب رفع صورة**
5. **شارك الرابط مع الفريق!**

---

## 🆘 مشاكل؟

إذا واجهت أي مشكلة:

1. افتح Console (F12)
2. شاهد الأخطاء
3. راجع `DEPLOYMENT.md` للتفاصيل الكاملة
4. راجع `TROUBLESHOOTING.md` لحل المشاكل

---

## 📞 الدعم السريع

**مشكلة**: صفحة بيضاء
**الحل**: تأكد من Environment Variables

**مشكلة**: Build failed
**الحل**: جرب `npm run build` محلياً

**مشكلة**: الملفات لا ترفع
**الحل**: راجع `STORAGE_SETUP.md`

---

## 🎊 تهانينا!

التطبيق الآن متاح على الإنترنت ويمكن لأي شخص الوصول إليه!

**مثال**:
```
الرابط: https://alwaleed-messaging.vercel.app
المستخدمون: يمكنهم التسجيل والدخول
الإدارة: admin / Admin@123
```

**لا تنسى تغيير كلمة مرور الإدارة!**

---

**آخر تحديث**: 16 يناير 2026
