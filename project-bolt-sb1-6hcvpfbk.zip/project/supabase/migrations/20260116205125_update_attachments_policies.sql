/*
  # تحديث سياسات المرفقات
  ## Update Attachments Policies
  
  1. تحديث سياسات RLS لـ message_attachments
  2. ملاحظة: Storage Bucket يجب إنشاؤه من لوحة Supabase
*/

-- ====================
-- حذف السياسات القديمة
-- ====================

DROP POLICY IF EXISTS "Enable read access for all users" ON message_attachments;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON message_attachments;
DROP POLICY IF EXISTS "Anyone can read attachments" ON message_attachments;
DROP POLICY IF EXISTS "Anyone can add attachments" ON message_attachments;

-- ====================
-- سياسات جديدة محسّنة
-- ====================

CREATE POLICY "Public read attachments"
ON message_attachments FOR SELECT
TO public
USING (true);

CREATE POLICY "Public insert attachments"
ON message_attachments FOR INSERT
TO public
WITH CHECK (
  file_name IS NOT NULL
  AND file_type IS NOT NULL
  AND file_url IS NOT NULL
  AND file_size > 0
  AND file_size <= 10485760
);

-- ====================
-- تعليقات
-- ====================

COMMENT ON TABLE message_attachments IS
'جدول المرفقات - يدعم الصور والملفات حتى 10MB. Storage Bucket: attachments';
