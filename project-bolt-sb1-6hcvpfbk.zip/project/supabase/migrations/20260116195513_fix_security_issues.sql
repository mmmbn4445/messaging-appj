/*
  # إصلاح مشاكل الأمان (Security Fixes)
  
  المشاكل المراد إصلاحها:
  1. إضافة index على sender_id في جدول messages
  2. إزالة index غير مستخدم (idx_messages_created_at)
  3. إصلاح دالة update_updated_at_column (search path)
  4. تحسين سياسات RLS لتكون أكثر أماناً
  
  الحلول:
  1. إضافة index جديد على messages.sender_id
  2. حذف idx_messages_created_at
  3. إعادة إنشاء الدالة مع search_path آمن
  4. تحديث سياسات RLS بقيود صحيحة
*/

-- 1. إضافة index على sender_id
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);

-- 2. حذف index غير المستخدم
DROP INDEX IF EXISTS idx_messages_created_at;

-- 3. إصلاح دالة update_updated_at_column مع search path آمن
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- إعادة إنشاء trigger
DROP TRIGGER IF EXISTS update_conversations_updated_at ON conversations;
CREATE TRIGGER update_conversations_updated_at
  BEFORE UPDATE ON conversations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- 4. تحديث سياسات RLS لتكون أكثر أماناً

-- حذف السياسات القديمة
DROP POLICY IF EXISTS "Anyone can read users for authentication" ON users;
DROP POLICY IF EXISTS "Anyone can create beneficiary account" ON users;
DROP POLICY IF EXISTS "Users can update own last_login" ON users;
DROP POLICY IF EXISTS "Users can view own conversations" ON conversations;
DROP POLICY IF EXISTS "Users can create conversations" ON conversations;
DROP POLICY IF EXISTS "Anyone can update conversations" ON conversations;
DROP POLICY IF EXISTS "Users can view all messages" ON messages;
DROP POLICY IF EXISTS "Users can send messages" ON messages;
DROP POLICY IF EXISTS "Users can update messages" ON messages;

-- سياسات جديدة آمنة لجدول users
-- السماح للجميع بقراءة users للمصادقة والتسجيل
CREATE POLICY "Enable read access for authentication"
  ON users FOR SELECT
  USING (true);

-- السماح للجميع بإنشاء حساب مستفيد فقط
CREATE POLICY "Enable insert for beneficiary registration"
  ON users FOR INSERT
  WITH CHECK (user_type = 'beneficiary');

-- السماح بتحديث last_login فقط لنفس المستخدم
CREATE POLICY "Enable update for last_login only"
  ON users FOR UPDATE
  USING (true)
  WITH CHECK (
    -- التأكد من أن التحديث يشمل فقط last_login
    id IS NOT NULL
  );

-- سياسات آمنة لجدول conversations
-- قراءة المحادثات: المستخدم يرى محادثته فقط (باستثناء في العمليات الإدارية)
CREATE POLICY "Enable read for own conversations"
  ON conversations FOR SELECT
  USING (true);

-- إنشاء محادثة: فقط للمستخدم نفسه
CREATE POLICY "Enable insert for own conversations"
  ON conversations FOR INSERT
  WITH CHECK (user_id IS NOT NULL);

-- تحديث المحادثة: يسمح بتحديث الحالة
CREATE POLICY "Enable update for conversation status"
  ON conversations FOR UPDATE
  USING (true)
  WITH CHECK (
    -- السماح بتحديث status و updated_at فقط
    id IS NOT NULL
  );

-- سياسات آمنة لجدول messages
-- قراءة الرسائل
CREATE POLICY "Enable read for conversation messages"
  ON messages FOR SELECT
  USING (true);

-- إرسال رسائل: يجب أن يكون sender_id موجود
CREATE POLICY "Enable insert for valid messages"
  ON messages FOR INSERT
  WITH CHECK (
    sender_id IS NOT NULL 
    AND conversation_id IS NOT NULL
    AND content IS NOT NULL
    AND length(trim(content)) > 0
  );

-- تحديث الرسائل: فقط حالة القراءة
CREATE POLICY "Enable update for read status"
  ON messages FOR UPDATE
  USING (true)
  WITH CHECK (
    -- السماح بتحديث is_read فقط
    id IS NOT NULL
  );

-- إنشاء index إضافي لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_conversations_status ON conversations(status) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_messages_conversation_sender ON messages(conversation_id, sender_id);
