/*
  # نظام مراسلات مؤسسة الوليد للإنسانية
  ## Al-Waleed Foundation Internal Messaging System
  
  1. الجداول الجديدة (New Tables)
    - `users` - جدول المستخدمين
      - `id` (uuid, primary key) - المعرف الفريد
      - `full_name` (text) - الاسم الكامل
      - `username` (text, unique) - اسم المستخدم
      - `password_hash` (text) - كلمة المرور المشفرة
      - `user_type` (text) - نوع المستخدم (beneficiary/admin)
      - `created_at` (timestamp) - تاريخ التسجيل
      - `last_login` (timestamp) - آخر تسجيل دخول
      
    - `conversations` - جدول المحادثات
      - `id` (uuid, primary key) - المعرف الفريد
      - `user_id` (uuid) - معرف المستخدم
      - `status` (text) - حالة المحادثة (active/closed)
      - `created_at` (timestamp) - تاريخ بدء المحادثة
      - `updated_at` (timestamp) - تاريخ آخر تحديث
      
    - `messages` - جدول الرسائل
      - `id` (uuid, primary key) - المعرف الفريد
      - `conversation_id` (uuid) - معرف المحادثة
      - `sender_id` (uuid) - معرف المرسل
      - `content` (text) - محتوى الرسالة
      - `is_from_admin` (boolean) - هل الرسالة من الإدارة
      - `is_read` (boolean) - هل تم قراءة الرسالة
      - `created_at` (timestamp) - تاريخ الإرسال
  
  2. الأمان (Security)
    - تفعيل RLS على جميع الجداول
    - المستخدمون يرون محادثاتهم فقط
    - الإداريون يرون جميع المحادثات
    - لا يمكن حذف الرسائل من قبل المستفيدين
  
  3. ملاحظات مهمة (Important Notes)
    - النظام لا يستخدم Supabase Auth المدمج
    - المصادقة مخصصة بدون بريد إلكتروني
    - كل مستفيد له محادثة واحدة مع المؤسسة
*/

-- إنشاء جدول المستخدمين
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  username text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  user_type text NOT NULL DEFAULT 'beneficiary' CHECK (user_type IN ('beneficiary', 'admin')),
  created_at timestamptz DEFAULT now(),
  last_login timestamptz DEFAULT now()
);

-- إنشاء جدول المحادثات
CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status text DEFAULT 'active' CHECK (status IN ('active', 'closed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- إنشاء جدول الرسائل
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  is_from_admin boolean DEFAULT false,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);

-- تفعيل RLS على جميع الجداول
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان لجدول المستخدمين
-- المستخدمون يمكنهم قراءة معلوماتهم الخاصة والإداريون يرون الجميع
CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  USING (
    id = current_setting('app.current_user_id', true)::uuid 
    OR 
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = current_setting('app.current_user_id', true)::uuid 
      AND user_type = 'admin'
    )
  );

-- سياسات الأمان لجدول المحادثات
-- المستخدمون يرون محادثاتهم فقط والإداريون يرون الجميع
CREATE POLICY "Users can view own conversations"
  ON conversations FOR SELECT
  USING (
    user_id = current_setting('app.current_user_id', true)::uuid
    OR
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = current_setting('app.current_user_id', true)::uuid 
      AND user_type = 'admin'
    )
  );

-- المستخدمون يمكنهم إنشاء محادثة لأنفسهم
CREATE POLICY "Users can create own conversation"
  ON conversations FOR INSERT
  WITH CHECK (user_id = current_setting('app.current_user_id', true)::uuid);

-- الإداريون فقط يمكنهم تحديث حالة المحادثة
CREATE POLICY "Admins can update conversation status"
  ON conversations FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = current_setting('app.current_user_id', true)::uuid 
      AND user_type = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = current_setting('app.current_user_id', true)::uuid 
      AND user_type = 'admin'
    )
  );

-- سياسات الأمان لجدول الرسائل
-- المستخدمون يرون رسائل محادثاتهم فقط والإداريون يرون الجميع
CREATE POLICY "Users can view messages in their conversations"
  ON messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = messages.conversation_id 
      AND conversations.user_id = current_setting('app.current_user_id', true)::uuid
    )
    OR
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = current_setting('app.current_user_id', true)::uuid 
      AND user_type = 'admin'
    )
  );

-- المستخدمون والإداريون يمكنهم إرسال رسائل
CREATE POLICY "Users can send messages"
  ON messages FOR INSERT
  WITH CHECK (
    sender_id = current_setting('app.current_user_id', true)::uuid
    AND
    (
      EXISTS (
        SELECT 1 FROM conversations 
        WHERE conversations.id = messages.conversation_id 
        AND conversations.user_id = current_setting('app.current_user_id', true)::uuid
      )
      OR
      EXISTS (
        SELECT 1 FROM users 
        WHERE id = current_setting('app.current_user_id', true)::uuid 
        AND user_type = 'admin'
      )
    )
  );

-- الإداريون فقط يمكنهم تحديث حالة قراءة الرسائل
CREATE POLICY "Admins and users can update message read status"
  ON messages FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = messages.conversation_id 
      AND conversations.user_id = current_setting('app.current_user_id', true)::uuid
    )
    OR
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = current_setting('app.current_user_id', true)::uuid 
      AND user_type = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM conversations 
      WHERE conversations.id = messages.conversation_id 
      AND conversations.user_id = current_setting('app.current_user_id', true)::uuid
    )
    OR
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = current_setting('app.current_user_id', true)::uuid 
      AND user_type = 'admin'
    )
  );

-- إنشاء دالة لتحديث updated_at تلقائياً
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- إضافة trigger لتحديث updated_at في جدول المحادثات
CREATE TRIGGER update_conversations_updated_at
  BEFORE UPDATE ON conversations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- إنشاء مستخدم إداري افتراضي (كلمة المرور: Admin@123)
-- ملاحظة: هذا مجرد مثال، يجب تغيير كلمة المرور لاحقاً
INSERT INTO users (full_name, username, password_hash, user_type)
VALUES (
  'إدارة المؤسسة',
  'admin',
  '$2a$10$rQ5YqLQJ5Lq5JQ5JQ5JQ5Ou.N3qYX5Wq5KQ5JQ5JQ5JQ5JQ5JQ5J.',
  'admin'
)
ON CONFLICT (username) DO NOTHING;