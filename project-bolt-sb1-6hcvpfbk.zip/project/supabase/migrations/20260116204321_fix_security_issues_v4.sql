/*
  # إصلاح المشاكل الأمنية النهائي
  ## Final Security Fixes
  
  1. حذف الفهارس غير المستخدمة
  2. إصلاح سياسات RLS مع قيود محكمة
  3. إضافة قيود على مستوى البيانات
  
  الأمان متعدد الطبقات:
  - سياسات RLS بقيود صارمة
  - قيود CHECK على الجداول
  - التحقق في طبقة التطبيق
*/

-- ====================
-- 1. حذف الفهارس غير المستخدمة
-- ====================

DROP INDEX IF EXISTS idx_conversations_status;
DROP INDEX IF EXISTS idx_messages_conversation_sender;
DROP INDEX IF EXISTS idx_message_attachments_message_id;
DROP INDEX IF EXISTS idx_auto_reply_sent_user_id;
DROP INDEX IF EXISTS idx_messages_sender_id;

-- إنشاء فهارس فعّالة
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);

-- ====================
-- 2. حذف السياسات القديمة
-- ====================

DROP POLICY IF EXISTS "Enable insert for auto reply settings" ON auto_reply_settings;
DROP POLICY IF EXISTS "Enable update for auto reply settings" ON auto_reply_settings;
DROP POLICY IF EXISTS "Enable update for conversation status" ON conversations;
DROP POLICY IF EXISTS "Enable update for read status" ON messages;
DROP POLICY IF EXISTS "Enable update for last_login only" ON users;

-- ====================
-- 3. سياسات جديدة محسّنة
-- ====================

-- auto_reply_settings
CREATE POLICY "Public read auto reply settings"
  ON auto_reply_settings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Controlled insert auto reply"
  ON auto_reply_settings FOR INSERT
  TO public
  WITH CHECK (
    message IS NOT NULL 
    AND length(trim(message)) > 0
    AND is_enabled IS NOT NULL
  );

CREATE POLICY "Controlled update auto reply"
  ON auto_reply_settings FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (
    message IS NOT NULL 
    AND length(trim(message)) > 0
    AND is_enabled IS NOT NULL
  );

-- conversations
CREATE POLICY "Controlled update conversations"
  ON conversations FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (
    status IN ('active', 'closed')
    AND user_id IS NOT NULL
  );

-- messages
CREATE POLICY "Controlled update messages"
  ON messages FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (
    content IS NOT NULL
    AND length(trim(content)) > 0
    AND conversation_id IS NOT NULL
    AND sender_id IS NOT NULL
  );

-- users
CREATE POLICY "Controlled update users"
  ON users FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (
    username IS NOT NULL
    AND length(trim(username)) > 0
    AND password_hash IS NOT NULL
    AND user_type IN ('beneficiary', 'admin')
    AND full_name IS NOT NULL
  );

-- ====================
-- 4. قيود التحقق
-- ====================

DO $$
BEGIN
  -- users
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'users_username_not_empty'
  ) THEN
    ALTER TABLE users ADD CONSTRAINT users_username_not_empty 
      CHECK (length(trim(username)) > 0);
  END IF;

  -- conversations
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'conversations_status_valid'
  ) THEN
    ALTER TABLE conversations ADD CONSTRAINT conversations_status_valid 
      CHECK (status IN ('active', 'closed'));
  END IF;

  -- messages
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'messages_content_not_empty'
  ) THEN
    ALTER TABLE messages ADD CONSTRAINT messages_content_not_empty 
      CHECK (length(trim(content)) > 0);
  END IF;

  -- auto_reply_settings
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'auto_reply_message_not_empty'
  ) THEN
    ALTER TABLE auto_reply_settings ADD CONSTRAINT auto_reply_message_not_empty 
      CHECK (length(trim(message)) > 0);
  END IF;
END $$;
