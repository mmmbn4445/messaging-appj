# دليل استكشاف الأخطاء وإصلاحها
## Troubleshooting Guide

---

## 🚨 المشاكل الشائعة وحلولها

### 1. الملفات والصور لا تظهر في المحادثة

#### الأعراض:
- لا تظهر الصور بعد إرسالها
- الملفات لا تُعرض في المحادثة
- رسالة "مرفق" بدون محتوى

#### الحلول:

##### أ) تأكد من إعداد Storage Bucket

**الخطوات:**

1. **افتح لوحة Supabase**
   ```
   https://supabase.com/dashboard
   ```

2. **اختر مشروعك**

3. **اذهب إلى Storage من القائمة الجانبية**

4. **تحقق من وجود bucket اسمه `attachments`**
   - إذا لم يكن موجوداً، أنشئه:
     - اضغط "New bucket"
     - الاسم: `attachments`
     - **Public bucket**: ✅ (مهم جداً!)
     - File size limit: `10485760` (10MB)
     - اضغط "Create bucket"

##### ب) تحقق من سياسات Storage

1. **اذهب إلى Storage > attachments > Policies**

2. **يجب أن تكون لديك 3 سياسات:**

**السياسة 1: القراءة العامة**
```sql
Policy name: Public read access for attachments
Allowed operation: SELECT
Target roles: public
Policy definition: (bucket_id = 'attachments')
```

**السياسة 2: الرفع**
```sql
Policy name: Authenticated users can upload attachments
Allowed operation: INSERT
Target roles: public
Policy definition: (bucket_id = 'attachments' AND (storage.foldername(name))[1] = 'messages')
```

**السياسة 3: الحذف**
```sql
Policy name: Users can delete own attachments
Allowed operation: DELETE
Target roles: public
Policy definition: (bucket_id = 'attachments')
```

##### ج) افحص Console للأخطاء

1. **افتح المتصفح**
2. **اضغط F12 لفتح Developer Tools**
3. **اذهب إلى تبويب Console**
4. **حاول رفع ملف وشاهد الرسائل**

**رسائل مفيدة ستظهر:**
- `Uploading file:` - يبدأ الرفع
- `Upload successful:` - تم الرفع بنجاح
- `Public URL:` - رابط الملف
- `Attachment saved successfully:` - تم الحفظ في قاعدة البيانات

**إذا رأيت خطأ:**
- `Upload error:` - خطأ في الرفع (تحقق من السياسات)
- `Error saving attachment:` - خطأ في الحفظ (تحقق من جدول message_attachments)

##### د) تحقق من جدول message_attachments

1. **اذهب إلى Table Editor في Supabase**
2. **افتح جدول `message_attachments`**
3. **تحقق من وجود السجلات**
4. **تأكد من أن `file_url` ليس فارغاً**

##### هـ) تحقق من RLS Policies

1. **اذهب إلى Table Editor > message_attachments**
2. **اضغط على زر الترس > Edit Table**
3. **اذهب إلى Policies**
4. **تأكد من وجود:**
   - `Public read attachments` (SELECT)
   - `Public insert attachments` (INSERT)

---

### 2. خطأ "Bucket not found"

#### الأعراض:
```
Upload error: {message: "Bucket not found"}
```

#### الحل:

1. **أنشئ bucket جديد:**
   - اذهب إلى Storage
   - اضغط "New bucket"
   - الاسم: `attachments`
   - Public: ✅
   - اضغط "Create"

2. **تحقق من الاسم:**
   - يجب أن يكون `attachments` بالضبط
   - بدون مسافات
   - بحروف صغيرة

---

### 3. خطأ "Permission denied"

#### الأعراض:
```
Upload error: {message: "new row violates row-level security policy"}
```

#### الحل:

1. **تأكد من أن Bucket هو Public**
   - اذهب إلى Storage > attachments
   - اضغط "Settings"
   - تأكد من تفعيل "Public bucket"

2. **راجع السياسات:**
   - يجب أن تسمح السياسات للجميع بالقراءة والكتابة

---

### 4. الصور تُرفع لكن لا تظهر

#### الأعراض:
- يتم رفع الملف بنجاح
- يُحفظ في قاعدة البيانات
- لكن لا يظهر في المحادثة

#### الحل:

1. **افحص رابط الصورة:**
   - اذهب إلى Table Editor > message_attachments
   - انسخ `file_url`
   - افتحه في متصفح جديد
   - إذا فتح الملف، المشكلة في العرض
   - إذا لم يفتح، المشكلة في الرفع

2. **تحقق من نوع الملف:**
   - تأكد من أن `file_type` يبدأ بـ `image/` للصور
   - الكود يتحقق من `attachment.file_type.startsWith('image/')`

3. **افحص الكود:**
   - افتح Console (F12)
   - ابحث عن أخطاء في تحميل الصور
   - قد تكون مشكلة CORS

---

### 5. الملفات لا تُحمّل (Download)

#### الأعراض:
- لا يمكن تحميل ملفات PDF أو Word

#### الحل:

1. **تأكد من أن الرابط صحيح:**
   - انقر بزر الماوس الأيمن على زر التحميل
   - اختر "Copy link"
   - افتح الرابط في متصفح جديد

2. **تحقق من سياسة القراءة:**
   - يجب أن تسمح للجميع بقراءة الملفات

---

### 6. رسالة "تأكد من إعداد Storage Bucket"

#### الأعراض:
- تظهر رسالة تنبيه عند محاولة رفع ملف

#### الحل:

هذا يعني أن:
- Bucket غير موجود، أو
- الاسم خطأ، أو
- هناك خطأ في الأذونات

**اتبع الخطوات في القسم 1 أعلاه**

---

### 7. الملفات الكبيرة لا تُرفع

#### الأعراض:
- الملفات الأكبر من 10MB تفشل

#### الحل:

1. **هذا طبيعي!**
   - الحد الأقصى هو 10MB

2. **لزيادة الحد الأقصى:**
   - اذهب إلى Storage > attachments > Settings
   - File size limit: غيّر القيمة
   - احفظ

3. **في الكود:**
   - افتح `ChatEnhanced.tsx`
   - ابحث عن `maxSize = 10 * 1024 * 1024`
   - غيّر القيمة حسب الحاجة

---

## 🔧 أدوات التشخيص

### 1. فحص Supabase Connection

افتح Console (F12) واكتب:

```javascript
console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL);
console.log('Supabase Key:', import.meta.env.VITE_SUPABASE_ANON_KEY ? 'موجود' : 'غير موجود');
```

### 2. اختبار رفع ملف

```javascript
const testUpload = async () => {
  const testFile = new File(['test'], 'test.txt', { type: 'text/plain' });

  const { data, error } = await supabase.storage
    .from('attachments')
    .upload(`messages/test-${Date.now()}.txt`, testFile);

  if (error) {
    console.error('خطأ:', error);
  } else {
    console.log('نجح! 🎉', data);
  }
};

testUpload();
```

### 3. فحص السياسات

```javascript
const checkPolicies = async () => {
  // محاولة قراءة
  const { data: readData, error: readError } = await supabase.storage
    .from('attachments')
    .list('messages');

  console.log('Read:', readError ? '❌' : '✅');

  // محاولة رفع
  const testFile = new File(['test'], 'test.txt', { type: 'text/plain' });
  const { error: uploadError } = await supabase.storage
    .from('attachments')
    .upload(`test-${Date.now()}.txt`, testFile);

  console.log('Upload:', uploadError ? '❌' : '✅');
};

checkPolicies();
```

---

## 📞 الحصول على المساعدة

إذا استمرت المشكلة:

1. **افتح Console (F12)**
2. **جرب رفع ملف**
3. **انسخ جميع رسائل الخطأ**
4. **التقط صورة شاشة من:**
   - رسالة الخطأ
   - Console
   - Storage settings في Supabase
5. **تواصل مع فريق الدعم**

---

## ✅ قائمة فحص سريعة

قبل طلب المساعدة، تحقق من:

- [ ] Storage Bucket `attachments` موجود
- [ ] Bucket مضبوط كـ Public
- [ ] File size limit = 10485760
- [ ] السياسات الثلاثة موجودة
- [ ] متغيرات البيئة `.env` صحيحة
- [ ] فحصت Console للأخطاء
- [ ] جربت رفع ملف صغير (< 1MB)
- [ ] فحصت جدول message_attachments

---

## 📚 مصادر إضافية

- [Supabase Storage Docs](https://supabase.com/docs/guides/storage)
- [Storage Policies](https://supabase.com/docs/guides/storage/security/access-control)
- [ملف STORAGE_SETUP.md](STORAGE_SETUP.md)
- [ملف APP_GUIDE.md](APP_GUIDE.md)

---

**آخر تحديث**: 16 يناير 2026
**الإصدار**: 1.0
